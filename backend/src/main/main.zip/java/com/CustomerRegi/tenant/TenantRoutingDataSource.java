package com.CustomerRegi.tenant;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;

@RequiredArgsConstructor
public class TenantRoutingDataSource extends AbstractRoutingDataSource {

	private final TenantDataSourceRegistry registry;
	private final DataSource masterDataSource;

	@Override
	protected Object determineCurrentLookupKey() {
		return TenantContext.getTenant();
	}

	@Override
	protected DataSource determineTargetDataSource() {
		String tenantId = (String) determineCurrentLookupKey();

		// No tenant → use MASTER DB
		if (tenantId == null) {
			return masterDataSource;
		}

		// tenant DB
		return registry.getDataSource("tenant_" + tenantId);
	}

}



//	@Override
//	protected DataSource determineTargetDataSource() {
//
//		String tenantId = TenantContext.getTenant();
//
//		if (tenantId == null) {
//			throw new IllegalStateException("No tenant set in TenantContext");
//		}
//
//		// tenantId == dbName in your design
//		return TenantDataSourceHolder.getDataSource(tenantId);
//	}


