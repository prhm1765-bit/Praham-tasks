package com.CustomerRegi.enums;

public enum Role {

	ADMIN,
	CUSTOMER

}
