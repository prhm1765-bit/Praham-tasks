package com.CustomerRegi.enums;

public enum AddressType {

	HOME,
	WORK,
	OTHER;

}
