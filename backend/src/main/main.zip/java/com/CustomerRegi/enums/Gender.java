package com.CustomerRegi.enums;

public enum Gender {

	MALE,
	FEMALE,
	OTHER;

}
