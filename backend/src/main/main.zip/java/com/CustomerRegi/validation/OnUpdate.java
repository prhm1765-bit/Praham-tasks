package com.CustomerRegi.validation;

public interface OnUpdate {
}
