package com.CustomerRegi.validation;

public interface OnCreate {
}
