package com.CustomerRegi.service;

import com.CustomerRegi.dto.LoginRequestDTO;

public interface AuthService {

	 String login(LoginRequestDTO loginRequestDTO);

}
