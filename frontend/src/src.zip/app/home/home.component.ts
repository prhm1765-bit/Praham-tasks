import { Component } from "@angular/core";

@Component({
  selector: "app-homepage",
  templateUrl: "./home.component.html", 
})
export class HomeComponent {
  // Component logic can be added here
  msg="Welcome to the Homepageeeeee";
  name="";
  salary=0;
  childMsg="";
  showChild=false;

  showChildComponent(){
    this.showChild=true;
  console.log("Name is: "+ this.name);
  console.log("Salary is: "+ this.salary);
}

 receiveMessageFromChild(messsage:string){
    this.childMsg=messsage;
 }
}