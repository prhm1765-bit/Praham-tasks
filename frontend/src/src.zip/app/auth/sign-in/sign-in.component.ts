import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { UserService } from "src/app/services/user.service";

@Component({
	selector: "app-sign-in",
	templateUrl: "./sign-in.component.html",
	styleUrls: ["./sign-in.component.css"]
})

export class SignInComponent implements OnInit {
	
	signInForm!: FormGroup;

	constructor(private fb : FormBuilder,
				private userService: UserService
	) {}

	ngOnInit(): void {
			this.signInForm = this.fb.group({
				email: ['', [Validators.required, Validators.email]],  
				password: ['', [Validators.required, Validators.minLength(6)]]
			});
	}

	submit() {
		if (this.signInForm.invalid) return;

		this.userService.signInUser(this.signInForm.value).subscribe({
				next: (res) => {
					console.log('User Signed In', res);
					alert('Sign in successful!');
				},
				error: (err) => {
					console.error('Error:', err);
					alert('Something went wrong!');
				}
				});
}

}